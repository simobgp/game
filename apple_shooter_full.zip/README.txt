Apple Shooter Flash Wrapper - Self-contained Version
======================================================

Purpose:
--------
This package gives you a self-contained HTML wrapper to run the Apple Shooter Flash game
using Ruffle without relying on external CDNs or cross-domain loading.

What you must supply yourself:
1. game.swf
   - Open your browser, go to:
     https://billybobgames.com/flash/appleshooter/
   - Open DevTools (F12), go to Network tab, filter by '.swf', reload the page,
     right-click on 'game.swf' request, open/save it. Save the file here as 'game.swf'.

2. Ruffle Web Build (self-hosted)
   - Download the latest **Web** build of Ruffle from its official GitHub releases page:
     https://github.com/ruffle-rs/ruffle/releases
   - In the downloaded archive, locate 'ruffle.js' and 'ruffle.wasm' (usually under the web build output).
   - Copy both into the 'ruffle/' subfolder in this package.

Directory structure after setup:
  apple_shooter_full/
    apple-shooter-ruffle-local.html
    game.swf
    ruffle/
      ruffle.js
      ruffle.wasm

How to use:
-----------
1. Host this entire folder on your web server (or open the HTML locally in a browser that allows local WASM loading).
2. Open 'apple-shooter-ruffle-local.html' in a browser.
3. The page will load Ruffle from local 'ruffle/ruffle.js' and your copied 'game.swf' and run the game.

Embedding:
----------
You can embed in another site using:
<iframe src="apple-shooter-ruffle-local.html" width="650" height="450" title="Apple Shooter"></iframe>

Troubleshooting:
----------------
- If the game doesn't load, open DevTools console to see if:
  * 'ruffle/ruffle.js' failed to load: ensure you placed it in the correct folder.
  * 'game.swf' failed to load: verify file is present and named exactly 'game.swf'.
- Some browsers restrict local WASM when opening via file://. It's best to serve via HTTP.
- This package does NOT include 'game.swf' due to copyright. You must obtain it yourself.

Generated: 2025-07-31 14:25 UTC
